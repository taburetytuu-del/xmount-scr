package com.xmount;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class XMount implements ModInitializer {
    public static final String MOD_ID = "xmount";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static int maintenanceTicks;

    @Override
    public void onInitialize() {
        XMountConfig.loadAsync();
        ServerTickEvents.END_SERVER_TICK.register(XMount::onServerTick);
        CommandRegistrationCallback.EVENT.register(XMount::registerCommands);
        LOGGER.info("XMount {} loaded: safe optimization profile is active", XMountConfig.VERSION);
    }

    private static void onServerTick(MinecraftServer server) {
        XMountConfig config = XMountConfig.get();
        maintenanceTicks++;
        int interval = Math.max(1, config.generalMaintenanceIntervalTicks);
        if (maintenanceTicks >= interval) {
            maintenanceTicks = 0;
            XMountRuntime.maintenance(server, config);
        }
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher,
                                         net.minecraft.commands.CommandBuildContext registryAccess,
                                         net.minecraft.commands.Commands.CommandSelection environment) {
        dispatcher.register(Commands.literal("xmount")
            .requires(source -> source.hasPermission(2))
            .then(Commands.literal("reload").executes(context -> {
                XMountConfig.reload();
                context.getSource().sendSuccess(() -> Component.literal("XMount config reloaded"), true);
                return 1;
            }))
            .then(Commands.literal("status").executes(context -> {
                XMountConfig c = XMountConfig.get();
                context.getSource().sendSuccess(() -> Component.literal(XMountConfig.statusLine(c)), false);
                return 1;
            })));
    }
}
