package com.xmount;

import net.fabricmc.api.ModInitializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class XMount implements ModInitializer {
    public static final String MOD_ID = "xmount";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        XMountConfig.loadAsync();
        LOGGER.info("XMount {} loaded for Minecraft 1.16.5", XMountConfig.VERSION);
    }
}
