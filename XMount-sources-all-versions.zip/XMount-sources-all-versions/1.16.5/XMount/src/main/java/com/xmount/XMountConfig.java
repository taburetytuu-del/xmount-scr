package com.xmount;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public final class XMountConfig {
    public static final String VERSION = "0.1.0";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("xmount.json");
    private static volatile XMountConfig INSTANCE = defaults();

    // Общие безопасные лимиты
    public int generalMaintenanceIntervalTicks = 20;
    public int chestPipeCheckIntervalTicks = 10;                 // 1
    public int mobPathSearchIntervalTicks = 10;                  // 2
    public int mobPathSearchRadius = 32;                         // 2
    public int modelPolygonBudget = 100;                          // 3 (индикатор для интеграций)
    public int textureMaxResolution = 1024;                       // 4
    public int serverPacketIntervalTicks = 1;                    // 5
    public int maxMobSpawnsPerChunk = 8;                          // 6
    public int workerThreads = 0;                                 // 7, 0 = auto
    public int allocationBatchSize = 64;                           // 8
    public boolean skipHiddenMechanismDetails = true;             // 9
    public boolean pauseUnloadedChunkBlockLogic = true;            // 10
    public int mechanismSimulationRadius = 8;                     // 11
    public int blockScreenAnimationIntervalTicks = 2;             // 12
    public int particleBudgetPerSecond = 250;                      // 13
    public int droppedItemLifetimeTicks = 6000;                    // 14
    public int dynamicLightUpdateIntervalTicks = 10;              // 15
    public int customPlantGrowthIntervalTicks = 20;               // 16
    public int nameplateRenderDistance = 32;                       // 17
    public int modTextureCacheMb = 128;                            // 18
    public int soundBudgetPerSecond = 32;                          // 19
    public int maxConcurrentCustomStructures = 1;                 // 20
    public int fluidSpreadIntervalTicks = 5;                      // 21
    public int customContainerSlots = 27;                         // 22
    public int deadMobCleanupDelayTicks = 20;                     // 23
    public boolean skipTinyProjectileHitboxes = true;             // 24
    public int energyGuiUpdateIntervalTicks = 5;                  // 25
    public int mobDangerCheckRadius = 8;                           // 26
    public int customEnchantmentComplexity = 2;                   // 27
    public int playerNbtBudgetKb = 256;                            // 28
    public boolean windAnimation = false;                          // 29
    public int advancementCheckIntervalTicks = 10;                // 30
    public int customOreGenerationPasses = 1;                     // 31
    public double customArmorDurabilityMultiplier = 1.0;          // 32
    public int mechanismSoundLoops = 4;                            // 33
    public int modPingIntervalTicks = 1200;                        // 34
    public int textureMemoryLifetimeSeconds = 120;                 // 35
    public float customExplosionRadiusMultiplier = 0.75f;         // 36
    public int fogColorTransitionTicks = 10;                      // 37
    public boolean prioritizeInventoryItemTextures = true;         // 38
    public boolean lightweightFallingBlockPhysics = true;          // 39
    public int projectileSyncIntervalTicks = 2;                   // 40
    public boolean cacheHeavyCraftingRecipes = true;               // 41
    public boolean asyncConfigLoading = true;                     // 42
    public int maxCustomDimensionShaders = 2;                     // 43
    public int customGlassLightReflections = 1;                   // 44
    public int recipeBookIconLoadBatchSize = 16;                  // 45
    public int updateCheckIntervalTicks = 0;                       // 46, 0 = disabled
    public int customBiomePacketChunkKb = 256;                    // 47
    public int dungeonGenerationThreads = 0;                       // 48, 0 = auto
    public boolean simplifiedVehiclePhysics = true;                // 49
    public int creativeTabCacheSeconds = 30;                      // 50

    private static XMountConfig defaults() { return new XMountConfig(); }
    public static XMountConfig get() { return INSTANCE; }

    public static void loadAsync() {
        if (INSTANCE.asyncConfigLoading) CompletableFuture.runAsync(XMountConfig::reload);
        else reload();
    }

    public static synchronized void reload() {
        try {
            Files.createDirectories(FILE.getParent());
            if (Files.exists(FILE)) {
                String json = new String(Files.readAllBytes(FILE), StandardCharsets.UTF_8);
                XMountConfig loaded = GSON.fromJson(json, XMountConfig.class);
                if (loaded != null) INSTANCE = loaded;
            } else {
                save(INSTANCE);
            }
            clamp(INSTANCE);
        } catch (Exception e) {
            XMount.LOGGER.warn("Could not load {}, using defaults", FILE, e);
            INSTANCE = defaults();
        }
    }

    private static void save(XMountConfig config) throws IOException {
        Files.write(FILE, GSON.toJson(config).getBytes(StandardCharsets.UTF_8));
    }

    private static void clamp(XMountConfig c) {
        c.generalMaintenanceIntervalTicks = Math.max(1, c.generalMaintenanceIntervalTicks);
        c.mobPathSearchRadius = Math.max(1, c.mobPathSearchRadius);
        c.particleBudgetPerSecond = Math.max(0, c.particleBudgetPerSecond);
        c.soundBudgetPerSecond = Math.max(0, c.soundBudgetPerSecond);
        c.nameplateRenderDistance = Math.max(0, c.nameplateRenderDistance);
        c.textureMaxResolution = Math.max(16, c.textureMaxResolution);
        c.droppedItemLifetimeTicks = Math.max(20, c.droppedItemLifetimeTicks);
        c.customExplosionRadiusMultiplier = Math.max(0.0f, Math.min(2.0f, c.customExplosionRadiusMultiplier));
    }

    public static String statusLine(XMountConfig c) {
        return "XMount: particles=" + c.particleBudgetPerSecond + "/s, sounds=" + c.soundBudgetPerSecond
            + "/s, mobPath=" + c.mobPathSearchRadius + "m/" + c.mobPathSearchIntervalTicks + "t"
            + ", mechanismRadius=" + c.mechanismSimulationRadius + ", texture=" + c.textureMaxResolution + "px";
    }
}
