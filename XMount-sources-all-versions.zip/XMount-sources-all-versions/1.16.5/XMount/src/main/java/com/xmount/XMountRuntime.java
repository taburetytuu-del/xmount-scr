package com.xmount;

/**
 * Central maintenance budget for integrations with machines, pipes and entities.
 * Legacy 1.16.5 integrations can use shouldRun instead of ticking every tick.
 */
public final class XMountRuntime {
    private static long maintenanceRuns;

    private XMountRuntime() {}

    public static void maintenance(XMountConfig config) {
        maintenanceRuns++;
        if (maintenanceRuns % 100 == 0) {
            XMount.LOGGER.debug("Maintenance run {}", maintenanceRuns);
        }
    }

    public static boolean shouldRun(long tick, int interval) {
        return interval <= 1 || tick % interval == 0;
    }

    public static long maintenanceRuns() {
        return maintenanceRuns;
    }
}
