package com.xmount.client;

import com.xmount.XMount;
import com.xmount.XMountConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

public final class XMountClient implements ClientModInitializer {
    private static long ticks;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(XMountClient::tick);
        XMount.LOGGER.info("XMount client profile enabled: hidden-detail culling={}, wind animation={}",
            XMountConfig.get().skipHiddenMechanismDetails, XMountConfig.get().windAnimation);
    }

    private static void tick(Minecraft client) {
        ticks++;
        if (ticks % 200 == 0) {
            XMountConfig.reload();
        }
    }
}
