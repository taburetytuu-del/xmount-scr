package com.xmount;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;

/**
 * Central maintenance budget. Integrations for custom pipes, machines and entities
 * can call shouldRun(...) instead of ticking every game tick.
 */
public final class XMountRuntime {
    private static long maintenanceRuns;
    private static long skippedUnloadedWorlds;

    private XMountRuntime() {}

    public static void maintenance(MinecraftServer server, XMountConfig config) {
        maintenanceRuns++;
        int activeWorlds = 0;
        for (ServerLevel level : server.getAllLevels()) {
            if (level.players().isEmpty()) {
                skippedUnloadedWorlds++;
                continue;
            }
            activeWorlds++;
        }
        if (maintenanceRuns % 100 == 0) {
            XMount.LOGGER.debug("Maintenance run {}: activeWorlds={}, skippedEmptyWorlds={}",
                maintenanceRuns, activeWorlds, skippedUnloadedWorlds);
        }
    }

    public static boolean shouldRun(long tick, int interval) {
        return interval <= 1 || tick % interval == 0;
    }

    public static long maintenanceRuns() { return maintenanceRuns; }
}
